var searchData=
[
  ['spi_5fdata_5fsize_213',['SPI_DATA_SIZE',['../_m_d___m_a_x72xx__lib_8h.html#a3d4a2b28815b437d2b2b2a38b0844cf9',1,'MD_MAX72xx_lib.h']]],
  ['spi_5foffset_214',['SPI_OFFSET',['../_m_d___m_a_x72xx__lib_8h.html#ad2df4aac8e44c45191f269fb0080f4ab',1,'MD_MAX72xx_lib.h']]]
];
